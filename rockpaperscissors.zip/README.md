[![Buy Me a Coffee](https://az743702.vo.msecnd.net/cdn/kofi3.png?v=0)](https://ko-fi.com/loki123)

# Rock, Paper, Scissors!
A simple FoundryVTT module that allows two people to play Rock, Paper, Scissors! Need I say more?

Requires socketlib and a GM to be online in the world.

The first player must type `rps` in the chat.
They will be greeted with a dropdown selection of every active user in the game world to play Rock, Paper, Scissors with!

![image](https://github.com/therealguy90/fvtt-rps/assets/100253440/62482d50-1191-40f4-84e3-18d867b86f84)

Simply press Start to play! After doing so, both players will be greeted with a selection of: Rock, Paper, or Scissors! Both players must click on **Shoot!** to finish the game!

![image](https://github.com/therealguy90/fvtt-rps/assets/100253440/526b410c-7a8f-4b18-ac3e-4b987fd95a34)
![image](https://github.com/therealguy90/fvtt-rps/assets/100253440/acd062e5-2699-4d72-990a-a75b8f3c98a7)

The results will be posted publicly.

![image](https://github.com/therealguy90/fvtt-rps/assets/100253440/c668754c-b019-4369-8b5b-eb4abe6e733b)

---

Thanks to <a href="https://www.vecteezy.com/free-vector/rock-paper-scissors">Rock Paper Scissors Vectors by Vecteezy</a> for the free vector assets used in this module.

